#define G 80

void print_pyramid(int pyramidSize);
