echo Hej hej
echo Välkommen
echo Tack så mycket